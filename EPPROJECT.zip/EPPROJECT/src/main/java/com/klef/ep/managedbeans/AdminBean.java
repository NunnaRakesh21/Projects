package com.klef.ep.managedbeans;

public class AdminBean {

}
