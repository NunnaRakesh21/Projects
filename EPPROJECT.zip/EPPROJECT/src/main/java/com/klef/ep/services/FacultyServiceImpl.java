package com.klef.ep.services;

import com.klef.ep.models.Faculty;

public class FacultyServiceImpl implements FacultyService
{

	@Override
	public Faculty CheckFacultyLogin(String email, String password) 
	{
		return null;
	}

	@Override
	public Faculty ViewFacultyProfile(int id) 
	{
		return null;
	}

}
